﻿namespace DbAccess.Contracts;

public interface IDatabaseService
{
    string Select<T>();
    string Insert<T>();
    string Update<T>();
    string Delete<T>();
    string CreateTable<T>();
}
