﻿namespace DbAccess.Contracts;

public interface IRepository<T>
{
    Task<T> Get(Guid id);
    Task<IEnumerable<T>> Get();
    Task<IEnumerable<T>> Get(object filter);
    Task Insert(T entity);
    Task Update(Guid id, T entity);
    Task Delete(Guid id);
}
public interface IExtendedRepository<T, TExtended> : IRepository<T>
{
    Task<TExtended> GetExtended(Guid id);
    Task<IEnumerable<TExtended>> GetExtended();
    Task<IEnumerable<TExtended>> GetExtended(object filter);

}
public interface ICrossReferenceRepository<T, TExtended, TA, TB> : IExtendedRepository<T, TExtended>
{
    Task<IEnumerable<TA>> GetA(Guid id);
    Task<IEnumerable<TB>> GetB(Guid id);
}