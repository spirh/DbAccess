﻿using DbAccess.Contracts;
using DbAccess.Domain.Contracts;
using DbAccess.Domain.Models;
using DbAccess.Services;
using System.Data;

namespace DbAccess.Domain.Services;

public class ResourceService : Repository<Resource>, IResourceService
{
    public ResourceService(IDbConnection dbConnection, IDatabaseService queryService) : base(dbConnection, queryService)
    {
    }
}