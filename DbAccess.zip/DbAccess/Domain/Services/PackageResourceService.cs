﻿using DbAccess.Contracts;
using DbAccess.Domain.Contracts;
using DbAccess.Domain.Models;
using DbAccess.Services;
using System.Data;

namespace DbAccess.Domain.Services;

public class PackageResourceService : CrossReferenceRepository<PackageResource, ExtPackageResource, Package, Resource>, IPackageResourceService
{
    public PackageResourceService(IDbConnection dbConnection, IDatabaseService queryService) : base(dbConnection, queryService)
    {
    }
}