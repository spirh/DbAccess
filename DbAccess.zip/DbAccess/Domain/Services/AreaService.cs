﻿using DbAccess.Contracts;
using DbAccess.Domain.Contracts;
using DbAccess.Domain.Models;
using DbAccess.Services;
using System.Data;

namespace DbAccess.Domain.Services;

public class AreaService : Repository<Area>, IAreaService
{
    public AreaService(IDbConnection dbConnection, IDatabaseService queryService) : base(dbConnection, queryService)
    {
    }
}
