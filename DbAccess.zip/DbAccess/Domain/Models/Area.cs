﻿namespace DbAccess.Domain.Models;

public class Area
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}