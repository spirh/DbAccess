﻿using DbAccess.Contracts;
using DbAccess.Domain.Models;

namespace DbAccess.Domain.Contracts;

public interface IPackageResourceService : ICrossReferenceRepository<PackageResource, ExtPackageResource, Package, Resource >
{

}
