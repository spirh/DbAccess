﻿using DbAccess.Contracts;
using DbAccess.Domain.Models;

namespace DbAccess.Domain.Contracts;
public interface IPackageService : IExtendedRepository<Package, ExtPackage>
{

}
