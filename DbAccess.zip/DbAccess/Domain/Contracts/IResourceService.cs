﻿using DbAccess.Contracts;
using DbAccess.Domain.Models;

namespace DbAccess.Domain.Contracts;

public interface IResourceService : IRepository<Resource>
{

}