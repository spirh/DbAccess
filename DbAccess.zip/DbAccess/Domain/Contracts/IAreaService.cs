﻿using DbAccess.Contracts;
using DbAccess.Domain.Models;

namespace DbAccess.Domain.Contracts;

public interface IAreaService : IRepository<Area>
{

}
