﻿using DbAccess.Contracts;

namespace DbAccess.Services;

public class PostgresQueryService : IDatabaseService
{
    public string CreateTable<T>()
    {
        throw new NotImplementedException();
    }

    public string Delete<T>()
    {
        throw new NotImplementedException();
    }

    public string Insert<T>()
    {
        throw new NotImplementedException();
    }

    public string Select<T>()
    {
        throw new NotImplementedException();
    }

    public string Update<T>()
    {
        throw new NotImplementedException();
    }
}
