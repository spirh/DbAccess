﻿using System.Data;
using DbAccess.Contracts;

namespace DbAccess.Services;

public class CrossReferenceRepository<T, TExtended, TA, TB> : ExtendedRepository<T, TExtended>, ICrossReferenceRepository<T, TExtended, TA, TB> where T : class
{
    public CrossReferenceRepository(IDbConnection dbConnection, IDatabaseService queryService) : base(dbConnection, queryService)
    {
    }

    public Task<IEnumerable<TA>> GetA(Guid id)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<TB>> GetB(Guid id)
    {
        throw new NotImplementedException();
    }
}
