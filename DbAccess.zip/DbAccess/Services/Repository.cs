﻿using System.Data;
using Dapper;
using DbAccess.Contracts;

namespace DbAccess.Services;
public class Repository<T> : IRepository<T> where T : class
{
    private readonly IDbConnection _dbConnection;
    private readonly IDatabaseService _queryService;

    public Repository(IDbConnection dbConnection, IDatabaseService queryService)
    {
        _dbConnection = dbConnection;
        _queryService = queryService;
    }

    public async Task<IEnumerable<T>> GetAll()
    {
        string query = _queryService.Select<T>();
        return await _dbConnection.QueryAsync<T>(query);
    }
    public async Task<T> Get(Guid id)
    {
        string query = _queryService.Select<T>();
        var res = await _dbConnection.QueryAsync<T>(query);
        return res.First();
    }
    public async Task Insert(T entity)
    {
        string query = _queryService.Insert<T>();
        await _dbConnection.ExecuteAsync(query, entity);
    }
    public async Task Update(Guid id, T entity)
    {
        string query = _queryService.Update<T>();
        await _dbConnection.ExecuteAsync(query, entity);
    }
    public async Task Delete(Guid id)
    {
        string query = _queryService.Update<T>();
        await _dbConnection.ExecuteAsync(query, id);
    }

    public Task<IEnumerable<T>> Get()
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<T>> Get(object filter)
    {
        throw new NotImplementedException();
    }
}
