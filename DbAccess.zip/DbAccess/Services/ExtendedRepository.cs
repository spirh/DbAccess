﻿using System.Data;
using DbAccess.Contracts;

namespace DbAccess.Services;

public class ExtendedRepository<T, TExtended> : Repository<T>, IExtendedRepository<T, TExtended> where T : class
{
    public ExtendedRepository(IDbConnection dbConnection, IDatabaseService queryService) : base(dbConnection, queryService)
    {
    }

    public Task<TExtended> GetExtended(Guid id)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<TExtended>> GetExtended()
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<TExtended>> GetExtended(object filter)
    {
        throw new NotImplementedException();
    }
}
